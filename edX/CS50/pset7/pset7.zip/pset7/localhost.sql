-- phpMyAdmin SQL Dump
-- version 3.5.8.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 13, 2014 at 08:21 PM
-- Server version: 5.5.32-MariaDB
-- PHP Version: 5.5.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pset7`
--
CREATE DATABASE `pset7` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `pset7`;

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE IF NOT EXISTS `history` (
  `id` int(11) NOT NULL,
  `transaction` varchar(255) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `symbol` varchar(255) NOT NULL,
  `shares` int(11) NOT NULL,
  `price` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`id`, `transaction`, `time`, `symbol`, `shares`, `price`) VALUES
(10, 'BUY', '2013-03-23 22:49:05', 'DNV.V', 100, 0.215),
(10, 'BUY', '2013-03-23 22:49:40', 'GOOG', 39, 810.31),
(10, 'BUY', '2013-03-23 22:50:36', 'GOOG', 20, 810.31),
(10, 'SELL', '2013-03-23 22:57:01', 'GOOG', 59, 810.31),
(7, 'BUY', '2013-03-23 23:03:05', 'GOOG', 3, 810.31),
(7, 'BUY', '2013-03-23 23:03:21', 'AA', 20, 8.45),
(11, 'BUY', '2014-10-13 03:54:58', 'GOOG', 1000, 544.49),
(11, 'SELL', '2014-10-13 03:55:38', 'GOOG', 1000, 544.49);

-- --------------------------------------------------------

--
-- Table structure for table `portfolio`
--

CREATE TABLE IF NOT EXISTS `portfolio` (
  `id` int(10) unsigned NOT NULL,
  `symbol` varchar(255) NOT NULL,
  `shares` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`,`symbol`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `portfolio`
--

INSERT INTO `portfolio` (`id`, `symbol`, `shares`) VALUES
(1, 'AAPL', 20),
(1, 'AMZN', 40),
(2, 'T', 20),
(3, 'AAPL', 50),
(3, 'BAC', 30),
(4, 'AMZN', 150),
(5, 'AA', 200),
(7, 'AA', 20),
(7, 'GOOG', 3),
(10, 'AA', 10),
(10, 'AAPL', 200),
(10, 'DNV.V', 100),
(10, 'T', 100);

-- --------------------------------------------------------

--
-- Table structure for table `stocks`
--

CREATE TABLE IF NOT EXISTS `stocks` (
  `userid` int(10) unsigned NOT NULL,
  `symbol` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `shares` int(10) unsigned NOT NULL,
  `price` double NOT NULL,
  PRIMARY KEY (`userid`,`symbol`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `stocks`
--

INSERT INTO `stocks` (`userid`, `symbol`, `shares`, `price`) VALUES
(22, 'AAPL', 100, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `hash` varchar(255) NOT NULL,
  `cash` decimal(65,4) unsigned NOT NULL DEFAULT '0.0000',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `hash`, `cash`) VALUES
(1, 'caesar', '$1$50$GHABNWBNE/o4VL7QjmQ6x0', '10000.0000'),
(2, 'cs50', '$1$50$ceNa7BV5AoVQqilACNLuC1', '10000.0000'),
(3, 'jharvard', '$1$50$RX3wnAMNrGIbgzbRYrxM1/', '10000.0000'),
(4, 'malan', '$1$HA$azTGIMVlmPi9W9Y12cYSj/', '10000.0000'),
(5, 'nate', '$1$50$sUyTaTbiSKVPZCpjJckan0', '10000.0000'),
(6, 'rbowden', '$1$50$lJS9HiGK6sphej8c4bnbX.', '10000.0000'),
(7, 'skroob', '$1$50$euBi4ugiJmbpIbvTTfmfI.', '7400.0700'),
(8, 'tmacwilliam', '$1$50$91ya4AroFPepdLpiX.bdP1', '10000.0000'),
(9, 'zamyla', '$1$50$Suq.MOtQj51maavfKvFsW1', '10000.0000'),
(10, 'jmhawkins', '$1$ecAoMAqX$trtHj77PEjwSXVKCdy/Qj0', '47818.2900'),
(11, 'prasanna', '$1$7fhp9Gzx$jUVulnDAL20Iz2h.oZGP9.', '544490.0000');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
