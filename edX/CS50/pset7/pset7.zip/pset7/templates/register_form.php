<form action="register.php" method="post">
    <fieldset>
        <div class="control-group">
            <input autofocus name="username" placeholder="Username" type="text"/>
        </div>
        <div class="control-group">
            <input name="password" placeholder="Password" type="password"/>
        </div>
        <div class="control-group">
            <input name="confirmation" placeholder="Confirm Password" type="password"/>
        </div>
        <div class="control-group">
            <input name="email" placeholder="Email Address" type="email"/>
        </div>
        <br>
        <div class="control-group">
            <button type="submit" class="btn">Create an account</button>
        </div>
    </fieldset>
</form>
<div>
    already got account? <a href="login.php">Log in</a>
</div>
