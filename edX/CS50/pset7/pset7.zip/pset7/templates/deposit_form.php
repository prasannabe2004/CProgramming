<?php
include 'common.php';
?>

<form action="deposit.php" method="post">
    <fieldset>
        <div class="control-group">
            <input class="input-medium" name="deposit" placeholder="Deposit Cash in $" type="text"/>
        </div>
        <div class="control-group">
            <br/>
            <button type="submit" class="btn">Deposit</button>
        </div>
    </fieldset>
</form>
