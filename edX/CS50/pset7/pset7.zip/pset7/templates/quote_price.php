<?php
include 'common.php';
?>
Today's value of <?=$_POST["name"]?> (<?=$_POST["symbol"]?>) is <strong>$<?=number_format($_POST["price"], 2)?></strong>
