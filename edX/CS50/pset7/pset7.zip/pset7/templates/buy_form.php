<?php
include 'common.php';
?>

<form action="buy.php" method="post">
    <fieldset>
        <div class="control-group">
            <input class="input-medium" name="symbol" placeholder="Symbol" type="text"/>
        </div>
        <div class="control-group">
            <input class="input-small" name="shares" placeholder="Shares" type="text"/>
        </div>
        <div class="control-group">
            <br/>
            <button type="submit" class="btn">Buy</button>
        </div>
    </fieldset>
</form>
